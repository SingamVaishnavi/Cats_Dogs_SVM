# Cats and Dogs Classification using SVM

## Objective
Classify images of cats and dogs using Support Vector Machine.

## Tools Used
- Python
- OpenCV
- NumPy
- Scikit-Learn

## Algorithm
Support Vector Machine (SVM)

## Steps
1. Load images.
2. Resize images.
3. Convert images into feature vectors.
4. Train SVM model.
5. Predict cat or dog.
6. Calculate accuracy.

## Output
Accuracy score showing classification performance.