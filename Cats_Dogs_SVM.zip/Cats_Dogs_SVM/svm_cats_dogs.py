import os
import cv2
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

data = []
labels = []

# Load Cat Images
for file in os.listdir("images/cats"):
    img = cv2.imread(os.path.join("images/cats", file))

    if img is not None:
        img = cv2.resize(img, (64, 64))
        data.append(img.flatten())
        labels.append(0)

# Load Dog Images
for file in os.listdir("images/dogs"):
    img = cv2.imread(os.path.join("images/dogs", file))

    if img is not None:
        img = cv2.resize(img, (64, 64))
        data.append(img.flatten())
        labels.append(1)

X = np.array(data)
y = np.array(labels)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = SVC(kernel='linear')

model.fit(X_train, y_train)

y_pred = model.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)

print("Accuracy:", accuracy)